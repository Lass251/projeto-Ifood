/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package testes;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;


    public class Pratilleira implements Initializable {

    @FXML
    private Label carrinho;
    @FXML
    private Button pagar;
    @FXML
    private Button voltar;
    @FXML
    private ListView<String> Alimentos;
    @FXML
    private Button adicionar;
    @FXML
    private Button finalizar;
    @FXML
    private Button limpar;
    @FXML
    private ListView<String> listaCarrinho;
    @FXML
    private Label infos;
    
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        popular();
     }    
    
    @FXML
    private void pagar(ActionEvent event) {
    }
    
    public void popular(){
        Alimentos.getItems().addAll(Pós_cadastro_estabelecimentoController.teste.toString());
    }
    

    @FXML
    private void voltar(ActionEvent event) throws Exception {
           utilitarios.changeToscene(getClass(), event, "TelaINICIAL.fxml");
    }

    @FXML
private void metodoAdd(ActionEvent event) {
    // Obter o item selecionado da ListView Alimentos
    String produtoSelecionado = Alimentos.getSelectionModel().getSelectedItem();

    // Verificar se um item foi selecionado
    if (produtoSelecionado != null) {
        // Adicionar o produto à ListView carrinho
        listaCarrinho.getItems().add(produtoSelecionado);
    }
}


    @FXML
private void metodoFinalizar(ActionEvent event) {
    // Exibir popup confirmando a finalização da compra
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle("Compra Finalizada");
    alert.setHeaderText(null);
    alert.setContentText("Sua compra foi finalizada com sucesso!");
    alert.showAndWait();

    // Limpar os itens da ListView carrinho
    listaCarrinho.getItems().clear();
}

    @FXML
private void metodoLimpar(ActionEvent event) {
    listaCarrinho.getItems().clear();
}

}
