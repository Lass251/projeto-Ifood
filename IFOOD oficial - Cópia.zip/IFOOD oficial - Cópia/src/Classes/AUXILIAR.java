/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;


    public class AUXILIAR {
    
    private int kkk;

    public AUXILIAR(int kkk) {
        this.kkk = kkk;
    }
   
    public int getKkk() {
        return kkk;
    }

    public void setKkk(int kkk) {
        this.kkk = kkk;
    } 
    }
